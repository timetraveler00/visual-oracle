EXP04 READ-ONLY OFFLINE PERFORMANCE BENCHMARK
=========================================
SSIM/PSNR: exact original formulas, separated for CPU timing.
DISTS, DINOv2-Base and OpenCLIP: original locked models and preprocessing.
Reference+receiver: two image embeddings per pair, where applicable.
Receiver_cached_reference: reference embeddings precomputed; reference
precomputation latency is separately reported.
full_offline_compute_no_disk: includes SSIM+PSNR, preprocessing and all
three deep metric computations; excludes image read and live capture.
deep_trio_batch_B: three deep models only, B pairs per batch; excludes
SSIM/PSNR, disk, preprocessing and network/capture overhead.
GPU times include synchronization and CPU-to-GPU tensor transfer.
Batch results are descriptive and cannot establish sustained live FPS.
Optional DINOv2-Large is NOT part of EXP04 frozen oracle.
Do not add these post-hoc runtime results to the frozen primary accuracy
evaluation or modify thresholds.
